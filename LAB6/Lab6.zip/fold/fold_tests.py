import unittest
from fold import *

class TestCases(unittest.TestCase):
   def test_1(self):
      # Add code here.
      pass


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

