import unittest
from char import *

class TestChar(unittest.TestCase):
   def test_lower(self):
      pass


if __name__ == '__main__':
   unittest.main()

